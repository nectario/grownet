# README Addendum: Golden Rule Doc Placement

Add the new doc right after the architecture overview in `READ_ORDER.md`:

- `docs/GOLDEN_RULE.md` (link text: *Golden Rule: Adapt vs Allocate (Slot→Neuron→Layer→Region)*)

If your repo has a docs index, add a bullet pointing to `docs/GOLDEN_RULE.md`.
