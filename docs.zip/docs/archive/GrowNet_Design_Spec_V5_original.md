# Archived: GrowNet Design Specification — V5 (original)

This file archives the original V5 spec that existed prior to introducing the merged master.

Note: The authoritative V5 spec is now:
- docs/GrowNet_Design_Spec_V5.md (Merged Master)

If you need the pre‑merge text, retrieve it from your VCS history prior to the merge, or compare with V4/V5_second to reconstruct minor phrasing differences. All functional requirements from the original are captured in the merged master.

