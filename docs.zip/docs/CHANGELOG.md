# GrowNet — Central Changelog Index

This file links to dated, detailed changelog entries under `docs/changelog/`.

Recent entries
- 2025-09-14 — TS parity (auto neuron growth, spatial metrics fix, policy alias, tests): docs/changelog/CHANGELOG_2025-09-14_TS_Parity_Autogrowth_Spatial_Metrics.md
- 2025-09-12 — PAL v2 (Java Virtual Threads, Python ThreadPool, Mojo GPU knob) + C++ naming cleanup: docs/changelog/CHANGELOG_2025-09-12_PAL_v2_and_Mojo_GPU_scaffold.md
- 2025-09-12 — PAL v1.5, demos, naming hygiene: docs/changelog/CHANGELOG_2025-09-12_PAL_v1_5_and_demos.md
- 2025-09-12 — smooth_clamp default smoothing changed to quintic: docs/changelog/CHANGELOG_2025-09-12_smooth_clamp_quintic_default.md

For earlier worklogs and PR-series notes, see the `docs/changelog/` and `docs/PRs/` folders.
