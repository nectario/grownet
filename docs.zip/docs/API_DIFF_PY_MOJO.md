# GrowNet API Diff — Python ↔ Mojo

**Divergence score:** 0.00%  

Totals: python_public=0, mojo_public=0, union=0, missing_in_mojo=0, missing_in_python=0, arity_mismatches=0


---
_This report compares public snake_case symbols (no leading underscores). Contract projection is heuristic if the YAML does not expose per-language sections explicitly._

