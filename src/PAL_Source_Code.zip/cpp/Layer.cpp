#include "Layer.h"
// All methods are inline in the header for simplicity.
