#include "ModulatoryNeuron.h"
// Definition is header-only; file provided for build systems that expect a .cpp.