from neuron import Neuron

class ExcitatoryNeuron(Neuron):
    # Inherit default fire: propagate to downstream
    pass
