// Proximity policy integration will be wired in a later phase.
