#include "Tract.h"
// Implementation is in the header (templated-style lambdas). Nothing additional here.
