package ai.nektron.grownet;

/** Region-scoped bus for inter-layer tracts and global pulses. */
public class RegionBus extends LateralBus {
    // Kept separate in case we add region-wide statistics or timing later.
}