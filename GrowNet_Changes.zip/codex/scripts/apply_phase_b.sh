#!/usr/bin/env bash
set -euo pipefail
codex apply codex/cr/CR-B-01-spatial-focus.yaml
codex apply codex/cr/CR-B-02-tests.yaml
